import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/enums/account_type.dart';
import '../../../core/models/social_link.dart';
import '../../../routes/app_routes.dart';
import 'widgets/experienced_niche_dialog.dart';
import 'package:dio/dio.dart';
import 'package:influencer_app/core/services/account_type_service.dart';
import 'package:influencer_app/core/services/auth_services.dart';
import 'package:influencer_app/modules/ad_agency/models/agency_onboarding_model.dart';
import 'package:influencer_app/modules/ad_agency/services/agency_onboarding_service.dart';

class SignupAgencyController extends GetxController {
  // ----------------- Step 1 (basic info) -----------------
  final formKey = GlobalKey<FormState>();

  final firstNameController = TextEditingController();
  final lastNameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();
  final authService = Get.find<AuthService>();
  final accountTypeService = Get.find<AccountTypeService>();
  final AgencyOnboardingService _agencyOnboardingService =
      Get.find<AgencyOnboardingService>();
  final isSubmitting = false.obs;
  final isFinishing = false.obs;

  void onContinue() async {
    if (isSubmitting.value) return;
    isSubmitting.value = true;
    if (firstNameController.text.trim().isEmpty ||
        lastNameController.text.trim().isEmpty ||
        emailController.text.trim().isEmpty ||
        phoneController.text.trim().isEmpty ||
        passwordController.text.trim().isEmpty) {
      Get.snackbar('Error', 'All fields are required');
      isSubmitting.value = false;
      return;
    }
    if (passwordController.text.trim().length < 8) {
      Get.snackbar('Error', 'Password must be at least 8 characters');
      isSubmitting.value = false;
      return;
    }
    try {
      final result = await authService.signup(
        firstName: firstNameController.text.trim(),
        lastName: lastNameController.text.trim(),
        email: emailController.text.trim(),
        phone: phoneController.text.trim(),
        password: passwordController.text.trim(),
        role: 'agency',
      );
      accountTypeService.setRole(AccountType.adAgency);
      Get.toNamed(
        AppRoutes.verification,
        arguments: {'phone': result.phone, 'accountType': AccountType.adAgency},
      );
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? e.response!.data['message']?.toString() ?? 'Signup failed'
          : e.message ?? 'Signup failed';
      Get.snackbar('Error', msg);
    } catch (e) {
      Get.snackbar('Error', e.toString());
    } finally {
      isSubmitting.value = false;
    }
  }

  // ----------------- Step 2 (address) -----------------
  final addressFormKey = GlobalKey<FormState>();

  final RxnString selectedThana = RxnString();
  final RxnString selectedZilla = RxnString();
  final fullAddressController = TextEditingController();

  final List<String> thanaOptions = const [
    'Dhanmondi',
    'Gulshan',
    'Banani',
    'Mirpur',
  ];

  final List<String> zillaOptions = const [
    'Dhaka',
    'Chattogram',
    'Barishal',
    'Sylhet',
  ];

  void onAddressContinue() {
    // if (addressFormKey.currentState?.validate() != true) return;
    Get.toNamed(AppRoutes.signupAgencyExpertise);
  }

  // ----------------- Step 3 (expertise / industries) -----------------
  final expertiseFormKey = GlobalKey<FormState>();

  // Dropdown options
  final List<String> platformOptions = const [
    'Facebook',
    'Instagram',
    'YouTube',
    'TikTok',
    'X (Twitter)',
    'Google Ads',
    'LinkedIn',
  ];

  /// Master list of niches – extend as you like
  final List<String> allNiches = const [
    'Public Speaking',
    'Voiceovers',
    'Podcasting',
    'Product Photography',
    'Conversion Optimization',
    'Technology',
    'Fashion',
    'Food & Beverage',
    'Travel',
    'Health & Fitness',
  ];

  // List of platform blocks shown in the UI
  final RxList<AgencyPlatformEntry> platforms = <AgencyPlatformEntry>[].obs;

  @override
  void onInit() {
    super.onInit();
    // start with one block
    platforms.add(AgencyPlatformEntry());
  }

  void addPlatform() {
    platforms.add(AgencyPlatformEntry());
  }

  void removePlatform(int index) {
    if (index < 0 || index >= platforms.length) return;
    final entry = platforms.removeAt(index);
    entry.dispose();
  }

  Future<void> openNicheDialog(AgencyPlatformEntry entry) async {
    final result = await Get.dialog<List<String>>(
      ExperiencedNicheDialog(
        initialSelected: entry.workedNiches.toList(),
        allNiches: allNiches,
      ),
    );

    if (result != null) {
      entry.workedNiches.assignAll(result);
      // Update the read-only summary field text
      entry.nicheSummaryController.text = result.isEmpty
          ? ''
          : result.join(', ');
    }
  }

  void removeWorkedNiche(AgencyPlatformEntry entry, String niche) {
    entry.workedNiches.remove(niche);
    entry.nicheSummaryController.text = entry.workedNiches.isEmpty
        ? ''
        : entry.workedNiches.join(', ');
  }

  void onExpertiseContinue() {
    // if (expertiseFormKey.currentState?.validate() != true) return;

    // TODO: send data to backend and navigate to next agency step / dashboard
    Get.toNamed(AppRoutes.signupAgencySocial);
  }

  // ----------------- Step 4 (social links) -----------------
  final socialFormKey = GlobalKey<FormState>();

  final websiteController = TextEditingController();
  final RxnString selectedPlatform = RxnString();
  final profileLinkController = TextEditingController();

  final RxList<SocialLink> socialLinks = <SocialLink>[].obs;

  void addAnotherLink() {
    if ((selectedPlatform.value == null ||
            selectedPlatform.value!.trim().isEmpty) ||
        profileLinkController.text.trim().isEmpty) {
      return;
    }

    socialLinks.add(
      SocialLink(
        website: websiteController.text.trim().isEmpty
            ? null
            : websiteController.text.trim(),
        platform: selectedPlatform.value!,
        profileUrl: profileLinkController.text.trim(),
      ),
    );

    selectedPlatform.value = null;
    profileLinkController.clear();
  }

  void onSocialContinue() {
    // if (socialFormKey.currentState?.validate() != true) return;
    Get.toNamed(AppRoutes.signupAgencyKyc);
  }

  // ----------------- Step 5 (KYC / NID) -----------------
  final nidFormKey = GlobalKey<FormState>();

  final nidNumberController = TextEditingController();
  final RxnString nidFrontPath = RxnString();
  final RxnString nidBackPath = RxnString();

  final ImagePicker _picker = ImagePicker();

  Future<void> pickNidFront() async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 2000,
      maxHeight: 2000,
      imageQuality: 85,
    );

    if (file != null) {
      nidFrontPath.value = file.path;
    }
  }

  Future<void> pickNidBack() async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 2000,
      maxHeight: 2000,
      imageQuality: 85,
    );

    if (file != null) {
      nidBackPath.value = file.path;
    }
  }

  void onKycSkip() {
    Get.toNamed(AppRoutes.signupAgencyTradeLicense);
  }

  void onKycSubmit() {
    // if (nidFormKey.currentState?.validate() != true) return;
    Get.toNamed(AppRoutes.signupAgencyTradeLicense);
  }

  // ----------------- Step 6 (trade license / KYC) -----------------
  final tradeLicenseFormKey = GlobalKey<FormState>();

  final tradeLicenseNumberController = TextEditingController();
  final RxnString tradeLicenseFilePath = RxnString();

  Future<void> pickTradeLicense() async {
    final XFile? file = await _picker.pickImage(source: ImageSource.gallery);

    if (file != null) {
      tradeLicenseFilePath.value = file.path;
    }
  }

  void onTradeLicenseContinue() {
    // if (tradeLicenseFormKey.currentState?.validate() != true) return;
    Get.toNamed(AppRoutes.signupAgencyTin);
  }

  void onTradeLicenseSkip() {
    Get.toNamed(AppRoutes.signupAgencyTin);
  }

  // ----------------- Step 7 (TIN / BIN) -----------------
  final tinFormKey = GlobalKey<FormState>();

  final tinNumberController = TextEditingController();
  final RxnString tinCertificatePath = RxnString();
  final binNumberController = TextEditingController();

  Future<void> pickTinCertificate() async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 2000,
      maxHeight: 2000,
      imageQuality: 85,
    );

    if (file != null) {
      tinCertificatePath.value = file.path;
    }
  }

  void onTinSkip() {
    _finishAgencySignup();
  }

  void onTinContinue() {
    // if (tinFormKey.currentState?.validate() != true) return;
    _finishAgencySignup();
  }

  Future<void> _finishAgencySignup() async {
    if (isFinishing.value) return;
    isFinishing.value = true;

    try {
      // 1) Submit onboarding (skip NID/uploads as requested)
      final onboarding = AgencyOnboardingModel()
        ..addressLine = _buildAddressLine()
        ..city = selectedZilla.value
        ..country = 'Bangladesh'
        ..website = websiteController.text.trim().isEmpty
            ? null
            : websiteController.text.trim()
        ..socialLinks = socialLinks
            .map(
              (s) => AgencySocialLink(
                platform: s.platform,
                url: s.profileUrl,
              ),
            )
            .toList();

      await _agencyOnboardingService.submitOnboarding(onboarding);

      // 2) Update niches (from expertise step)
      final niches = _collectUniqueNiches();
      if (niches.isNotEmpty) {
        await _agencyOnboardingService.updateNiches(niches);
      }

      Get.offAllNamed(
        AppRoutes.signupSuccess,
        arguments: {'accountType': AccountType.adAgency},
      );
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? (e.response!.data['message']?.toString() ?? 'Signup completion failed')
          : (e.message ?? 'Signup completion failed');
      Get.snackbar('Error', msg);
    } catch (e) {
      Get.snackbar('Error', e.toString());
    } finally {
      isFinishing.value = false;
    }
  }

  String? _buildAddressLine() {
    final addr = fullAddressController.text.trim();
    final thana = selectedThana.value?.trim();

    if (addr.isEmpty && (thana == null || thana.isEmpty)) return null;
    if (addr.isEmpty) return thana;
    if (thana == null || thana.isEmpty) return addr;
    return '$addr, $thana';
  }

  List<String> _collectUniqueNiches() {
    final set = <String>{};
    for (final entry in platforms) {
      for (final n in entry.workedNiches) {
        final v = n.trim();
        if (v.isNotEmpty) set.add(v);
      }
    }
    return set.toList();
  }

  // ----------------- Navigation helpers -----------------
  void goBack() {
    Get.back();
  }

  void goToLogin() {
    Get.offAllNamed(AppRoutes.login);
  }

  @override
  void onClose() {
    // (kept simple as this controller may stay alive across steps)
    super.onClose();
  }
}

/// One block of "platform + niches + worked niches"
class AgencyPlatformEntry {
  final RxnString selectedPlatform = RxnString();

  /// What the user has selected for this platform
  final RxList<String> workedNiches = <String>[].obs;

  /// Read-only summary text shown in the "Select Niches" field
  final TextEditingController nicheSummaryController = TextEditingController();

  void dispose() {
    nicheSummaryController.dispose();
  }
}

class SignupAgencyBinding extends Bindings {
  @override
  void dependencies() {
    // Keep one controller instance across the entire multi-step flow.
    if (!Get.isRegistered<SignupAgencyController>()) {
      Get.put(SignupAgencyController(), permanent: true);
    }
  }
}
