// lib/modules/auth/forgot_password/forgot_password_controller.dart
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:influencer_app/core/services/auth_services.dart';
import '../../../routes/app_routes.dart';

class ForgotPasswordController extends GetxController {
  // ----------------- Services -----------------
  final AuthService authService = Get.find<AuthService>();

  // ----------------- Step 1: contact (phone / email) -----------------
  final contactFormKey = GlobalKey<FormState>();
  final contactController = TextEditingController();

  // value used in the OTP subtitle: "We sent a code to ..."
  final RxString contactValue = ''.obs;

  final RxBool isSending = false.obs;

  // Flag to prevent accessing controllers after navigation starts
  bool _isNavigating = false;

  Future<void> onSendResetLink() async {
    contactValue.value = contactController.text.trim();

    if (contactValue.value.isEmpty) {
      Get.snackbar('Error', 'Please enter email or phone');
      return;
    }

    try {
      isSending.value = true;

      final res = await authService.forgotPassword(
        identifier: contactValue.value,
      );

      Get.snackbar('Success', res.message);

      Get.toNamed(
        AppRoutes.forgotPasswordOtp,
        arguments: {'contact': contactValue.value},
      );
    } on DioException catch (e) {
      final data = e.response?.data;
      final msg = (data is Map && data['message'] != null)
          ? data['message'].toString()
          : (e.message ?? 'An error occurred');

      Get.snackbar('Error', msg);
    } catch (_) {
      Get.snackbar('Error', 'An unexpected error occurred');
    } finally {
      isSending.value = false;
    }
  }

  // ----------------- Step 2: OTP -----------------
  final otpFormKey = GlobalKey<FormState>();

  late final List<TextEditingController> otpControllers;
  late final List<FocusNode> otpFocusNodes;

  // for enabling/disabling Continue button
  final RxBool isOtpComplete = false.obs;

  // store verified OTP so reset step can use it
  final RxString verifiedOtp = ''.obs;

  // loading state for verify/resend
  final RxBool isVerifyingOtp = false.obs;
  final RxBool isResending = false.obs;

  String get otpCode => otpControllers.map((c) => c.text).join();

  void onOtpDigitChanged(String value, int index) {
    if (value.isNotEmpty) {
      if (index < otpFocusNodes.length - 1) {
        otpFocusNodes[index + 1].requestFocus();
      } else {
        otpFocusNodes[index].unfocus();
      }
    } else {
      if (index > 0) {
        otpFocusNodes[index - 1].requestFocus();
      }
    }

    isOtpComplete.value = otpCode.length == 4;
  }

  Future<void> resendCode() async {
    if (contactValue.value.isEmpty) {
      Get.snackbar('Error', 'Missing contact info');
      return;
    }

    // clear boxes UI
    for (final c in otpControllers) {
      c.clear();
    }
    isOtpComplete.value = false;
    verifiedOtp.value = '';
    if (otpFocusNodes.isNotEmpty) {
      otpFocusNodes.first.requestFocus();
    }

    try {
      isResending.value = true;

      // IMPORTANT:
      // Postman only has forgot-password + verify-otp + reset-password.
      // There is NO dedicated "resend forgot password OTP" endpoint.
      // So "resend" = call forgotPassword again.
      final res = await authService.forgotPassword(
        identifier: contactValue.value,
      );

      Get.snackbar('Success', res.message);
    } on DioException catch (e) {
      final data = e.response?.data;
      final msg = (data is Map && data['message'] != null)
          ? data['message'].toString()
          : (e.message ?? 'An error occurred');

      Get.snackbar('Error', msg);
    } catch (_) {
      Get.snackbar('Error', 'An unexpected error occurred');
    } finally {
      isResending.value = false;
    }
  }

  Future<void> onVerifyOtp() async {
    if (!isOtpComplete.value) return;
    if (contactValue.value.isEmpty) {
      Get.snackbar('Error', 'Missing contact info');
      return;
    }

    final code = otpCode;
    if (code.length != 4) {
      Get.snackbar('Error', 'OTP must be 4 digits');
      return;
    }

    try {
      isVerifyingOtp.value = true;

      await authService.forgotPasswordVerifyOtp(
        identifier: contactValue.value,
        otp: code,
      );

      verifiedOtp.value = code;

      Get.toNamed(AppRoutes.resetPassword);
    } on DioException catch (e) {
      final data = e.response?.data;
      final msg = (data is Map && data['message'] != null)
          ? data['message'].toString()
          : (e.message ?? 'OTP verification failed');

      Get.snackbar('Error', msg);
    } catch (_) {
      Get.snackbar('Error', 'An unexpected error occurred');
    } finally {
      isVerifyingOtp.value = false;
    }
  }

  // ----------------- Step 3: reset password -----------------
  final resetFormKey = GlobalKey<FormState>();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  final RxBool isResetting = false.obs;

  Future<void> onResetPassword() async {
    final newPass = passwordController.text.trim();
    final confirm = confirmPasswordController.text.trim();

    if (contactValue.value.isEmpty) {
      Get.snackbar('Error', 'Missing contact info');
      return;
    }
    if (verifiedOtp.value.isEmpty) {
      Get.snackbar('Error', 'OTP not verified');
      return;
    }
    if (newPass.isEmpty || confirm.isEmpty) {
      Get.snackbar('Error', 'Please enter password and confirm password');
      return;
    }
    if (newPass.length < 8) {
      Get.snackbar('Error', 'Password must be at least 8 characters');
      return;
    }
    if (newPass != confirm) {
      Get.snackbar('Error', 'Passwords do not match');
      return;
    }

    try {
      isResetting.value = true;

      await authService.resetPassword(
        identifier: contactValue.value,
        otp: verifiedOtp.value,
        newPassword: newPass,
      );

      Get.toNamed(AppRoutes.resetPasswordSuccess);
    } on DioException catch (e) {
      final data = e.response?.data;
      final msg = (data is Map && data['message'] != null)
          ? data['message'].toString()
          : (e.message ?? 'Reset password failed');

      Get.snackbar('Error', msg);
    } catch (_) {
      Get.snackbar('Error', 'An unexpected error occurred');
    } finally {
      isResetting.value = false;
    }
  }

  // ----------------- Navigation helpers -----------------
  void goBack() => Get.back();

  void goToLogin() {
    // close keyboard first (prevents TextInput from touching controller during pop)
    // FocusManager.instance.primaryFocus?.unfocus();

    // // Navigate next frame so current build finishes cleanly
    // WidgetsBinding.instance.addPostFrameCallback((_) {
    //   if (!isClosed) {
    //     Get.offAllNamed(AppRoutes.login);
    //   }
    // });
    //Get.offAllNamed(AppRoutes.login);
    // 1) close keyboard / detach text input cleanly
    FocusManager.instance.primaryFocus?.unfocus();

    // 2) clear stack on next microtask (safe teardown)
    Future.microtask(() {
      if (!isClosed) {
        Get.offAllNamed(AppRoutes.login);
      }
    });
  }

  // Getter to check if navigation is in progress
  bool get isNavigating => _isNavigating;

  // ----------------- Lifecycle -----------------
  @override
  void onInit() {
    super.onInit();

    otpControllers = List.generate(4, (_) => TextEditingController());
    otpFocusNodes = List.generate(4, (_) => FocusNode());

    final args = Get.arguments;
    if (args is Map && args['contact'] is String) {
      contactValue.value = args['contact'] as String;
    }

    Future.microtask(() {
      if (otpFocusNodes.isNotEmpty) otpFocusNodes.first.requestFocus();
    });
  }

  @override
  void onClose() {
    // keep local references (safe even if lists are later cleared)
    final contact = contactController;
    final otps = List<TextEditingController>.from(otpControllers);
    final nodes = List<FocusNode>.from(otpFocusNodes);
    final pass = passwordController;
    final confirm = confirmPasswordController;

    // IMPORTANT: Dispose AFTER frame, not immediately.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      contact.dispose();
      for (final c in otps) c.dispose();
      for (final f in nodes) f.dispose();
      pass.dispose();
      confirm.dispose();
    });

    super.onClose();
  }
}

class ForgotPasswordBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<ForgotPasswordController>(ForgotPasswordController());
  }
}
