import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/enums/account_type.dart';
import '../../../core/models/social_link.dart';
import '../../../core/services/account_type_service.dart';
import '../../../core/services/auth_services.dart';
import '../../../routes/app_routes.dart';

import '../../influencer/models/influencer_onboarding_model.dart';
import '../../influencer/services/influencer_onboarding_services.dart';

class SignupInfluencerController extends GetxController {
  // ----------------- Services -----------------
  final AccountTypeService accountTypeService = Get.find<AccountTypeService>();
  final AuthService _authService = Get.find<AuthService>();
  final InfluencerOnboardingService _onboardingService =
      Get.find<InfluencerOnboardingService>();

  final isSubmitting = false.obs;

  // ----------------- Aggregated Onboarding Data -----------------
  final InfluencerOnboardingModel onboardingData = InfluencerOnboardingModel();

  // ----------------- Step 1 (basic info) -----------------
  final formKey = GlobalKey<FormState>();

  final brandNameController =
      TextEditingController(); // (unused for influencer)
  final firstNameController = TextEditingController();
  final lastNameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController(); // ✅ required

  Future<void> onStep1Continue() async {
    if (isSubmitting.value) return;
    // if (formKey.currentState?.validate() != true) return;

    final firstName = firstNameController.text.trim();
    final lastName = lastNameController.text.trim();
    final email = emailController.text.trim();
    final phone = phoneController.text.trim();
    final password = passwordController.text;

    if (firstName.isEmpty ||
        lastName.isEmpty ||
        email.isEmpty ||
        phone.isEmpty ||
        password.isEmpty) {
      Get.snackbar('Error', 'All fields are required');
      return;
    }
    if (password.length < 8) {
      Get.snackbar('Error', 'Password must be at least 8 characters');
      return;
    }

    try {
      isSubmitting.value = true;

      // ✅ Backend signup (sends OTP)
      final res = await _authService.signup(
        firstName: firstName,
        lastName: lastName,
        email: email,
        phone: phone,
        password: password,
        role: 'influencer',
      );

      accountTypeService.setRole(AccountType.influencer);

      // ✅ Go OTP screen with confirmed phone
      Get.toNamed(
        AppRoutes.verification,
        arguments: {'phone': res.phone, 'accountType': AccountType.influencer},
      );
    } on DioException catch (e) {
      final data = e.response?.data;
      final msg = (data is Map && data['message'] != null)
          ? data['message'].toString()
          : (e.message ?? 'Signup failed');
      Get.snackbar('Error', msg);
    } finally {
      isSubmitting.value = false;
    }
  }

  // ----------------- Step 2 (address) -----------------
  final addressFormKey = GlobalKey<FormState>();

  final RxnString selectedThana = RxnString();
  final RxnString selectedZilla = RxnString();
  final fullAddressController = TextEditingController();

  final List<String> thanaOptions = const [
    'Dhanmondi',
    'Gulshan',
    'Banani',
    'Mirpur',
  ];
  final List<String> zillaOptions = const [
    'Dhaka',
    'Chattogram',
    'Barishal',
    'Sylhet',
  ];

  void onAddressContinue() {
    // if (addressFormKey.currentState?.validate() != true) return;

    onboardingData.fullAddress = fullAddressController.text.trim();
    onboardingData.thana = selectedThana.value;
    onboardingData.zilla = selectedZilla.value;

    Get.toNamed(AppRoutes.signupInfluencerSocial);
  }

  // ----------------- Step 3 (social links) -----------------
  final socialFormKey = GlobalKey<FormState>();

  final websiteController = TextEditingController();
  final RxnString selectedPlatform = RxnString();
  final profileLinkController = TextEditingController();

  final List<String> platformOptions = const [
    'Facebook',
    'Instagram',
    'YouTube',
    'TikTok',
    'X (Twitter)',
  ];

  final RxList<SocialLink> socialLinks = <SocialLink>[].obs;

  void addAnotherLink() {
    if ((selectedPlatform.value == null ||
            selectedPlatform.value!.trim().isEmpty) ||
        profileLinkController.text.trim().isEmpty) {
      return;
    }

    socialLinks.add(
      SocialLink(
        website: websiteController.text.trim().isEmpty
            ? null
            : websiteController.text.trim(),
        platform: selectedPlatform.value!,
        profileUrl: profileLinkController.text.trim(),
      ),
    );

    selectedPlatform.value = null;
    profileLinkController.clear();
  }

  void removeLink(int index) {
    if (index >= 0 && index < socialLinks.length) {
      socialLinks.removeAt(index);
    }
  }

  void onSocialContinue() {
    onboardingData.website = websiteController.text.trim().isEmpty
        ? null
        : websiteController.text.trim();

    // ✅ freeze snapshot
    onboardingData.socialLinks = List<SocialLink>.from(socialLinks);

    Get.toNamed(AppRoutes.signupInfluencerKyc);
  }

  // ----------------- Step 4 (KYC / NID) -----------------
  final nidFormKey = GlobalKey<FormState>();

  final nidNumberController = TextEditingController();
  final RxnString nidFrontPath = RxnString();
  final RxnString nidBackPath = RxnString();

  final ImagePicker _picker = ImagePicker();

  Future<void> pickNidFront() async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 2000,
      maxHeight: 2000,
      imageQuality: 85,
    );
    if (file != null) nidFrontPath.value = file.path;
  }

  Future<void> pickNidBack() async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 2000,
      maxHeight: 2000,
      imageQuality: 85,
    );
    if (file != null) nidBackPath.value = file.path;
  }

  void onKycSkip() {
    Get.toNamed(
      AppRoutes.signupSuccess,
      arguments: {'accountType': AccountType.influencer},
    );
  }

  Future<void> onKycSubmit() async {
    if (isSubmitting.value) return;
    // if (nidFormKey.currentState?.validate() != true) return;

    try {
      isSubmitting.value = true;

      onboardingData.nidNumber = nidNumberController.text.trim().isEmpty
          ? null
          : nidNumberController.text.trim();

      // NOTE: These are local paths. If backend expects URLs,
      // we must add upload endpoint later.
      onboardingData.nidFrontImg = nidFrontPath.value;
      onboardingData.nidBackImg = nidBackPath.value;

      // ✅ FINAL: submit onboarding
      await _onboardingService.submitOnboarding(onboardingData);

      // ✅ success screen
      Get.toNamed(
        AppRoutes.signupSuccess,
        arguments: {'accountType': AccountType.influencer},
      );
    } on DioException catch (e) {
      final data = e.response?.data;
      final msg = (data is Map && data['message'] != null)
          ? data['message'].toString()
          : (e.message ?? 'Onboarding submit failed');
      Get.snackbar('Error', msg);
    } finally {
      isSubmitting.value = false;
    }
  }

  // ----------------- Navigation helpers -----------------
  void goToLogin() => Get.offAllNamed(AppRoutes.login);
  void goBack() => Get.back();

  @override
  void onClose() {
    brandNameController.dispose();
    firstNameController.dispose();
    lastNameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    passwordController.dispose();

    fullAddressController.dispose();
    websiteController.dispose();
    profileLinkController.dispose();

    nidNumberController.dispose();
    super.onClose();
  }
}
