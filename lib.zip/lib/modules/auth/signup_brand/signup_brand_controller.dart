// lib/modules/auth/signup_brand/signup_brand_controller.dart
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:influencer_app/core/services/account_type_service.dart';
import 'package:influencer_app/core/services/auth_services.dart';
import 'package:influencer_app/modules/ad_agency/services/upload_service.dart';
import 'package:influencer_app/modules/brand/models/onboarding_models.dart';
import 'package:influencer_app/modules/brand/services/brand_onboarding_services.dart';
import '../../../core/enums/account_type.dart';
import '../../../core/models/social_link.dart';
import '../../../routes/app_routes.dart';
import 'package:dio/dio.dart';
import 'package:path/path.dart' as path;

// Helper class to collect onboarding data across steps
class _MutableBrandOnboardingData {
  String? zila;
  String? fullAddress;
  String? website;
  List<BrandSocialLink> socialLinks = [];
  String? nidNumber;
  String? nidFrontImg;
  String? nidBackImg;
  String? tradeLicenseNumber;
  String? tradeLicenseImg;
}

class SignupBrandController extends GetxController {
  // ----------------- Step 1 (basic info) -----------------
  final formKey = GlobalKey<FormState>();

  final brandNameController = TextEditingController();
  final firstNameController = TextEditingController();
  final lastNameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();
  final authService = Get.find<AuthService>();
  final accountTypeService = Get.find<AccountTypeService>();
  final _onboardingService = Get.find<BrandOnboardingService>();
  final _uploadService = Get.find<UploadService>();

  // Onboarding data collection (using mutable fields)
  final onboardingData = _MutableBrandOnboardingData();

  // Loading states
  final isUploadingNid = false.obs;
  final isUploadingTradeLicense = false.obs;
  final isUploadingTin = false.obs;
  final isFinishing = false.obs;

  // language toggle
  final isEnglish = true.obs;

  void setLanguage(String code) {
    if (code == 'en') {
      isEnglish.value = true;
      Get.updateLocale(const Locale('en', 'US'));
    } else {
      isEnglish.value = false;
      Get.updateLocale(const Locale('bn', 'BD'));
    }
  }

  final isSubmitting = false.obs;

  void onContinue() async {
    if (isSubmitting.value) return;
    isSubmitting.value = true;
    if (firstNameController.text.trim().isEmpty ||
        lastNameController.text.trim().isEmpty ||
        emailController.text.trim().isEmpty ||
        phoneController.text.trim().isEmpty ||
        passwordController.text.trim().isEmpty ||
        brandNameController.text.trim().isEmpty) {
      Get.snackbar('Error', 'All fields are required');
      isSubmitting.value = false;
      return;
    }
    if (passwordController.text.trim().length < 8) {
      Get.snackbar('Error', 'Password must be at least 8 characters');
      isSubmitting.value = false;
      return;
    }
    try {
      final result = await authService.signup(
        firstName: firstNameController.text.trim(),
        lastName: lastNameController.text.trim(),
        email: emailController.text.trim(),
        phone: phoneController.text.trim(),
        password: passwordController.text.trim(),
        role: 'brand',
      );
      accountTypeService.setRole(AccountType.brand);
      Get.toNamed(
        AppRoutes.verification,
        arguments: {'phone': result.phone, 'accountType': AccountType.brand},
      );
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? e.response!.data['message']?.toString() ?? 'Signup failed'
          : e.message ?? 'Signup failed';
      Get.snackbar('Error', msg);
    } catch (e) {
      Get.snackbar('Error', e.toString());
    } finally {
      isSubmitting.value = false;
    }
  }

  // ----------------- Step 2 (address) -----------------
  final addressFormKey = GlobalKey<FormState>();

  final RxnString selectedThana = RxnString();
  final RxnString selectedZilla = RxnString();
  final fullAddressController = TextEditingController();

  final List<String> thanaOptions = const [
    'Dhanmondi',
    'Gulshan',
    'Banani',
    'Mirpur',
  ];

  final List<String> zillaOptions = const [
    'Dhaka',
    'Chattogram',
    'Barishal',
    'Sylhet',
  ];

  void onAddressContinue() {
    // Save address data to onboarding model
    onboardingData.zila = selectedZilla.value;
    onboardingData.fullAddress = fullAddressController.text.trim().isEmpty
        ? null
        : fullAddressController.text.trim();

    Get.toNamed(AppRoutes.signupBrandSocial);
  }

  // ----------------- Step 3 (social links) -----------------
  final socialFormKey = GlobalKey<FormState>();

  final websiteController = TextEditingController();
  final RxnString selectedPlatform = RxnString();
  final profileLinkController = TextEditingController();

  final List<String> platformOptions = const [
    'Facebook',
    'Instagram',
    'YouTube',
    'TikTok',
    'X (Twitter)',
  ];

  final RxList<SocialLink> socialLinks = <SocialLink>[].obs;

  void addAnotherLink() {
    if ((selectedPlatform.value == null ||
            selectedPlatform.value!.trim().isEmpty) ||
        profileLinkController.text.trim().isEmpty) {
      return;
    }

    socialLinks.add(
      SocialLink(
        website: websiteController.text.trim().isEmpty
            ? null
            : websiteController.text.trim(),
        platform: selectedPlatform.value!,
        profileUrl: profileLinkController.text.trim(),
      ),
    );

    selectedPlatform.value = null;
    profileLinkController.clear();
  }

  void onSocialContinue() {
    // Save social links and website to onboarding model
    onboardingData.website = websiteController.text.trim().isEmpty
        ? null
        : websiteController.text.trim();

    // Convert SocialLink to BrandSocialLink
    onboardingData.socialLinks = socialLinks
        .map(
          (link) =>
              BrandSocialLink(platform: link.platform, link: link.profileUrl),
        )
        .toList();

    Get.toNamed(AppRoutes.signupBrandKyc);
  }

  // ----------------- Step 4 (KYC / NID) -----------------
  final nidFormKey = GlobalKey<FormState>();

  final nidNumberController = TextEditingController();
  final RxnString nidFrontPath = RxnString();
  final RxnString nidBackPath = RxnString();

  final ImagePicker _picker = ImagePicker();

  Future<void> pickNidFront() async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 2000,
      maxHeight: 2000,
      imageQuality: 85,
    );

    if (file != null) {
      nidFrontPath.value = file.path;
    }
  }

  Future<void> pickNidBack() async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 2000,
      maxHeight: 2000,
      imageQuality: 85,
    );

    if (file != null) {
      nidBackPath.value = file.path;
    }
  }

  void onKycSkip() {
    Get.toNamed(AppRoutes.signupBrandTradeLicense);
  }

  Future<void> onKycSubmit() async {
    if (isUploadingNid.value) return;

    // Save NID number if provided
    final nidNumber = nidNumberController.text.trim();
    if (nidNumber.isNotEmpty) {
      onboardingData.nidNumber = nidNumber;
    }

    // Upload NID images if provided
    try {
      isUploadingNid.value = true;

      if (nidFrontPath.value != null) {
        final frontUrl = await _uploadFile(
          filePath: nidFrontPath.value!,
          module: 'brand-kyc',
        );
        onboardingData.nidFrontImg = frontUrl;
      }

      if (nidBackPath.value != null) {
        final backUrl = await _uploadFile(
          filePath: nidBackPath.value!,
          module: 'brand-kyc',
        );
        onboardingData.nidBackImg = backUrl;
      }

      Get.toNamed(AppRoutes.signupBrandTradeLicense);
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? e.response!.data['message']?.toString() ?? 'NID upload failed'
          : e.message ?? 'NID upload failed';
      Get.snackbar('Error', msg);
    } catch (e) {
      Get.snackbar('Error', 'Failed to upload NID: ${e.toString()}');
    } finally {
      isUploadingNid.value = false;
    }
  }

  // ----------------- Step 5 (trade license / KYC) -----------------
  final tradeLicenseFormKey = GlobalKey<FormState>();

  final tradeLicenseNumberController = TextEditingController();
  final RxnString tradeLicenseFilePath = RxnString();

  Future<void> pickTradeLicense() async {
    final XFile? file = await _picker.pickImage(source: ImageSource.gallery);

    if (file != null) {
      tradeLicenseFilePath.value = file.path;
    }
  }

  Future<void> onTradeLicenseContinue() async {
    if (isUploadingTradeLicense.value) return;

    // Save trade license number if provided
    final tradeLicenseNumber = tradeLicenseNumberController.text.trim();
    if (tradeLicenseNumber.isNotEmpty) {
      onboardingData.tradeLicenseNumber = tradeLicenseNumber;
    }

    // Upload trade license image if provided
    try {
      isUploadingTradeLicense.value = true;

      if (tradeLicenseFilePath.value != null) {
        final tradeLicenseUrl = await _uploadFile(
          filePath: tradeLicenseFilePath.value!,
          module: 'brand-trade-license',
        );
        onboardingData.tradeLicenseImg = tradeLicenseUrl;
      }

      Get.toNamed(AppRoutes.signupBrandTin);
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? e.response!.data['message']?.toString() ??
                'Trade license upload failed'
          : e.message ?? 'Trade license upload failed';
      Get.snackbar('Error', msg);
    } catch (e) {
      Get.snackbar('Error', 'Failed to upload trade license: ${e.toString()}');
    } finally {
      isUploadingTradeLicense.value = false;
    }
  }

  void onTradeLicenseSkip() {
    Get.toNamed(AppRoutes.signupBrandTin);
  }

  // ----------------- Step 6 (TIN / BIN) -----------------
  final tinFormKey = GlobalKey<FormState>();

  final tinNumberController = TextEditingController();
  final RxnString tinCertificatePath = RxnString();
  final binNumberController = TextEditingController();

  Future<void> pickTinCertificate() async {
    final XFile? file = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 2000,
      maxHeight: 2000,
      imageQuality: 85,
    );

    if (file != null) {
      tinCertificatePath.value = file.path;
    }
  }

  void onTinSkip() {
    // Submit onboarding without TIN
    _finishBrandSignup();
  }

  Future<void> onTinContinue() async {
    if (isFinishing.value) return;

    // Upload TIN certificate if provided
    try {
      isUploadingTin.value = true;

      if (tinCertificatePath.value != null) {
        // Note: TIN/BIN is not in BrandOnboardingRequest model
        // If backend requires it, add tinCertificateUrl field to model
        await _uploadFile(
          filePath: tinCertificatePath.value!,
          module: 'brand-tin',
        );
        // TODO: Add TIN certificate URL to model if backend requires it
      }

      // Submit onboarding
      _finishBrandSignup();
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? e.response!.data['message']?.toString() ?? 'TIN upload failed'
          : e.message ?? 'TIN upload failed';
      Get.snackbar('Error', msg);
    } catch (e) {
      Get.snackbar('Error', 'Failed to upload TIN: ${e.toString()}');
    } finally {
      isUploadingTin.value = false;
    }
  }

  // ----------------- File Upload Helper -----------------

  /// Upload a file and return the public URL
  Future<String> _uploadFile({
    required String filePath,
    required String module,
  }) async {
    final file = File(filePath);
    if (!await file.exists()) {
      throw Exception('File not found: $filePath');
    }

    // Get file info
    final fileName = path.basename(filePath);
    final fileExtension = path.extension(fileName).replaceFirst('.', '');
    final contentType = _getContentType(fileExtension);

    // Step 1: Get signed URL
    final signedUrlResult = await _uploadService.createSignedUrl(
      fileName: fileName,
      fileType: contentType,
      module: module,
    );

    // Step 2: Upload to cloud storage
    await _uploadService.uploadFileToSignedUrl(
      uploadUrl: signedUrlResult.uploadUrl,
      file: file,
      contentType: contentType,
    );

    // Step 3: Return public URL
    return signedUrlResult.fileUrl;
  }

  /// Get content type from file extension
  String _getContentType(String extension) {
    switch (extension.toLowerCase()) {
      case 'jpg':
      case 'jpeg':
        return 'image/jpeg';
      case 'png':
        return 'image/png';
      case 'pdf':
        return 'application/pdf';
      default:
        return 'image/jpeg';
    }
  }

  // ----------------- Final Submission -----------------

  /// Collect all data and submit brand onboarding
  Future<void> _finishBrandSignup() async {
    if (isFinishing.value) return;

    try {
      isFinishing.value = true;

      // Collect data before navigation (in case controllers get disposed)
      final brandName = brandNameController.text.trim();
      final firstName = firstNameController.text.trim();
      final lastName = lastNameController.text.trim();

      // Update basic info (brandName, firstName, lastName)
      await _onboardingService.updateBasicInfo(
        brandName: brandName,
        firstName: firstName,
        lastName: lastName,
      );

      // Build final onboarding request with all collected data
      final request = BrandOnboardingRequest(
        profile: brandName, // brand name/bio
        zila: onboardingData.zila,
        fullAddress: onboardingData.fullAddress,
        website: onboardingData.website,
        socialLinks: onboardingData.socialLinks,
        nidNumber: onboardingData.nidNumber,
        nidFrontImg: onboardingData.nidFrontImg,
        nidBackImg: onboardingData.nidBackImg,
        tradeLicenseNumber: onboardingData.tradeLicenseNumber,
        tradeLicenseImg: onboardingData.tradeLicenseImg,
      );

      // Submit onboarding data
      await _onboardingService.submitOnboarding(request);

      // Navigate to success screen (this removes previous routes)
      Get.offAllNamed(
        AppRoutes.signupSuccess,
        arguments: {'accountType': AccountType.brand},
      );
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? (e.response!.data['message']?.toString() ??
                'Onboarding submission failed')
          : (e.message ?? 'Onboarding submission failed');
      Get.snackbar('Error', msg);
    } catch (e) {
      Get.snackbar('Error', 'Failed to complete signup: ${e.toString()}');
    } finally {
      // Only reset if controller is still active
      if (!isClosed) {
        isFinishing.value = false;
      }
    }
  }

  // ----------------- Common navigation -----------------
  void goToLogin() {
    Get.offAllNamed('/login');
  }

  void goBack() {
    Get.back();
  }

  // IMPORTANT: do NOT dispose the TextEditingControllers here
  // because this controller is shared across multiple steps and is permanent.
  // The controllers should remain alive for the entire signup flow.
  @override
  void onClose() {
    // Don't dispose controllers - they're needed across multiple steps
    // Since the controller is permanent, GetX won't automatically dispose it
    // Only call super.onClose() - GetX will handle cleanup if needed
    super.onClose();
  }

}

class SignupBrandBinding extends Bindings {
  @override
  void dependencies() {
    // keep controller alive across all brand signup steps
    Get.put<SignupBrandController>(SignupBrandController(), permanent: true);
  }
}
