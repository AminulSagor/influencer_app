// lib/modules/auth/verification/verification_controller.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:influencer_app/routes/app_routes.dart';
import 'package:influencer_app/core/services/auth_services.dart';
import '../../../core/enums/account_type.dart';
import 'package:dio/dio.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:influencer_app/core/services/auth_services.dart';

class VerificationController extends GetxController {
  final PageController progressController = PageController();

  // 4-digit OTP controllers + focus nodes
  final List<TextEditingController> digitControllers = List.generate(
    4,
    (_) => TextEditingController(),
  );
  final List<FocusNode> focusNodes = List.generate(4, (_) => FocusNode());
  final RxBool isLoading = false.obs;
  late final String phoneNumber;
  late final AccountType accountType;

  final RxBool isCodeComplete = false.obs;

  String get code => digitControllers.map((c) => c.text.trim()).join();
  final AuthService _authService = Get.find<AuthService>();
  @override
  void onInit() {
    super.onInit();
    final args = Get.arguments as Map<String, dynamic>?;

    phoneNumber = args?['phone'] as String? ?? '';
    accountType =
        args?['accountType'] as AccountType? ?? AccountType.influencer;

    for (final c in digitControllers) {
      c.addListener(_handleCodeChange);
    }

    if (digitControllers.isNotEmpty) {
      focusNodes.first.requestFocus();
    }
  }

  void _handleCodeChange() {
    isCodeComplete.value = code.length == digitControllers.length;
  }

  /// Called from each field's onChanged
  void onDigitChanged(String value, int index) {
    // keep only the last character if user pasted/typed multiple
    if (value.length > 1) {
      final last = value.characters.last;
      digitControllers[index]
        ..text = last
        ..selection = TextSelection.fromPosition(const TextPosition(offset: 1));
    }

    if (digitControllers[index].text.isNotEmpty &&
        index < focusNodes.length - 1) {
      focusNodes[index + 1].requestFocus();
    } else if (digitControllers[index].text.isEmpty && index > 0) {
      focusNodes[index - 1].requestFocus();
    }

    _handleCodeChange();
  }

  void onBack() {
    Get.back();
  }

  void onResend() async {
    // TODO: call API to resend OTP
    try {
      final response = await _authService.resendOtp(phone: phoneNumber);
      if (response.message.isNotEmpty) {
        Get.snackbar('info'.tr, response.message);
      }
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? e.response!.data['message']?.toString() ?? 'OTP resend failed'
          : e.message ?? 'OTP resend failed';

      Get.snackbar('Error', msg);
    } catch (e) {
      Get.snackbar('Error', e.toString());
    }
  }

  Future<void> onContinue() async {
    if (!isCodeComplete.value) {
      Get.snackbar('error'.tr, 'otp_incomplete_error'.tr);
      return;
    }

    final enteredCode = code;

    try {
      isLoading.value = true;

      // Verify OTP with backend
      final tokenResult = await _authService.verifyOtp(
        phone: phoneNumber,
        otp: enteredCode,
      );

      final token = tokenResult.accessToken;

      // Decode JWT
      final payload = JwtDecoder.decode(token);

      // Extract role
      final role =
          payload['role'] ??
          payload['accountType'] ??
          (payload['user'] is Map ? payload['user']['role'] : null);

      if (role == null) {
        throw Exception('Role not found in token');
      }

      //navigate to phone verified screen
      Get.offAllNamed(AppRoutes.phoneVerified);
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? e.response!.data['message']?.toString() ?? 'OTP verification failed'
          : e.message ?? 'OTP verification failed';

      Get.snackbar('Error', msg);
    } catch (e) {
      Get.snackbar('Error', e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  void onPhoneVerifiedGoNext() {
    // Navigate according to account type
    switch (accountType) {
      case AccountType.brand:
        Get.offAllNamed(AppRoutes.signupBrandAddress);
        break;
      case AccountType.influencer:
        Get.toNamed(AppRoutes.signupInfluencerAddress);
        break;
      case AccountType.adAgency:
        Get.offAllNamed(AppRoutes.signupAgencyAddress);
        break;
    }
  }

  void goToLogin() {
    Get.offAllNamed('/login');
  }

  @override
  void onClose() {
    for (final c in digitControllers) {
      c.dispose();
    }
    for (final f in focusNodes) {
      f.dispose();
    }
    super.onClose();
  }
}

class VerificationBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<VerificationController>(() => VerificationController());
  }
}
