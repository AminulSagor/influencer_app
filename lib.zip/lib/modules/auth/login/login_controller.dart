// lib/modules/auth/login/login_controller.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:influencer_app/core/enums/account_type.dart';
import 'package:influencer_app/core/services/account_type_service.dart';
import 'package:influencer_app/core/services/auth_services.dart';
import '../../../routes/app_routes.dart';
import 'package:dio/dio.dart';
import 'package:jwt_decoder/jwt_decoder.dart';
import 'package:influencer_app/core/services/token_service.dart';

class LoginController extends GetxController {
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  final RxBool isPasswordObscured = true.obs;
  final RxBool isLoading = false.obs;

  final _accountTypeService = Get.find<AccountTypeService>();
  final _authService = Get.find<AuthService>();
  final _tokenService = Get.find<TokenService>();

  void togglePasswordVisibility() {
    isPasswordObscured.toggle();
  }

  Future<void> submitLogin() async {
    // simple placeholder
    // if (phoneController.text.isEmpty || passwordController.text.isEmpty) {
    //   Get.snackbar('Error', 'Please fill all fields');
    //   return;
    // }
    final phone = phoneController.text.trim();
    final password = passwordController.text.trim();
    if (phone.isEmpty || password.isEmpty) {
      Get.snackbar(
        'error'.tr,
        'please_fill_all_fields'.tr,
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    isLoading.value = true;
    // await Future.delayed(const Duration(milliseconds: 600));
    try {
      isLoading.value = true;

      final tokenResult = await _authService.login(
        phone: phone,
        password: password,
      );

      final token = tokenResult.accessToken;
      await _tokenService.saveAccessToken(token);
      // Decode JWT
      final payload = JwtDecoder.decode(token);

      // Extract role from token
      final role =
          payload['role'] ??
          payload['accountType'] ??
          (payload['user'] is Map ? payload['user']['role'] : null);

      if (role == null) {
        throw Exception('Role not found in token');
      }

      if (role == 'influencer') {
        _accountTypeService.setRole(AccountType.influencer);
        //Get.offAllNamed(AppRoutes.influencerHomeLocked);
      } else if (role == 'brand') {
        _accountTypeService.setRole(AccountType.brand);
        //Get.offAllNamed(AppRoutes.brandHomeLocked);
      } else if (role == 'agency') {
        _accountTypeService.setRole(AccountType.adAgency);
        //Get.offAllNamed(AppRoutes.agencyHomeLocked);
      } else if (role == 'admin') {
        // future admin panel route
        //Get.offAllNamed(AppRoutes.adminHome);
        Get.offAllNamed(AppRoutes.onboarding);
      } else {
        // fallback
        Get.offAllNamed(AppRoutes.onboarding);
      }
      Get.snackbar('Success', tokenResult.message);
      Get.offAllNamed(AppRoutes.bottomNav);
    } on DioException catch (e) {
      final msg = (e.response?.data is Map)
          ? (e.response?.data['message']?.toString() ?? 'Login failed')
          : (e.message ?? 'Login failed');

      Get.snackbar('Diohttp-Error', msg);
    } catch (e) {
      Get.snackbar('Code-Error', e.toString());
    } finally {
      isLoading.value = false;
    }
    isLoading.value = false;

    // _accountTypeService.setRole(AccountType.adAgency);
    // _accountTypeService.setRole(AccountType.influencer);
    //_accountTypeService.setRole(AccountType.brand);

    Get.offAllNamed(AppRoutes.bottomNav);
  }

  void goToSignUp() {
    Get.toNamed(AppRoutes.signupAccountType);
  }

  void forgotPassword() {
    Get.toNamed(AppRoutes.forgotPassword);
  }

  @override
  void onClose() {
    phoneController.dispose();
    passwordController.dispose();
    super.onClose();
  }
}

class LoginBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<LoginController>(() => LoginController());
  }
}
