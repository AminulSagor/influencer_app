/// Payload for: PATCH /agency/profile/onboarding
///
/// Based on the provided Postman collection:
/// {
///   "addressLine": "...",
///   "city": "...",
///   "country": "...",
///   "website": "...",
///   "socialLinks": [{"platform":"Facebook","url":"https://..."}]
/// }
class AgencyOnboardingModel {
  String? addressLine;
  String? city;
  String? country;
  String? website;

  /// backend expects: [{platform, url}]
  List<AgencySocialLink> socialLinks = [];

  Map<String, dynamic> toJson() => {
        "addressLine": addressLine,
        "city": city,
        "country": country,
        "website": website,
        "socialLinks": socialLinks.map((e) => e.toJson()).toList(),
      };
}

class AgencySocialLink {
  final String platform;
  final String url;

  AgencySocialLink({required this.platform, required this.url});

  Map<String, dynamic> toJson() => {"platform": platform, "url": url};
}
