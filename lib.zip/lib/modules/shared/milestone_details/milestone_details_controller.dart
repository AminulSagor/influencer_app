// lib/modules/ad_agency/milestone_details/milestone_details_controller.dart
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../core/models/job_item.dart';
import '../../../core/services/account_type_service.dart';
import '../../../core/services/api_client.dart';
import '../../../core/services/api_error_handler.dart';
import '../../../core/theme/app_palette.dart';
import 'widgets/brand_submission_card.dart';

/// Local status used for the big status card
enum MilestoneLocalStatus {
  toDo,
  inReview,
  paid,
  approved,
  partialPaid,
  declined,
  completed,
}

class AdminReportModel {
  final String reason;
  final DateTime createdAt;

  AdminReportModel({required this.reason, required this.createdAt});
}

class SubmissionUiModel {
  final int index;
  String? serverId;

  // form controllers
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController amountController = TextEditingController();
  final TextEditingController linkController = TextEditingController();
  final TextEditingController metricLabelController = TextEditingController(
    text: 'Reach',
  );
  final TextEditingController metricValueController = TextEditingController();

  // files + state
  final RxList<PlatformFile> proofs = <PlatformFile>[].obs;
  final RxBool isExpanded = true.obs;

  final Rx<SubmissionStatus> status = SubmissionStatus.inReview.obs;
  final RxBool isSubmitted =
      false.obs; // when true and not declined -> lock fields until edit again

  SubmissionUiModel({required this.index});

  bool get isEditable =>
      !isSubmitted.value || status.value == SubmissionStatus.declined;

  void dispose() {
    descriptionController.dispose();
    amountController.dispose();
    linkController.dispose();
    metricLabelController.dispose();
    metricValueController.dispose();
  }
}

class MilestoneDetailsController extends GetxController {
  MilestoneDetailsController(this.arguments);

  final dynamic arguments;

  late final JobItem job;
  // not final because we reassign updated copy
  late Milestone milestone;

  final RxBool headerExpanded = true.obs;

  // status for big status card
  final Rx<MilestoneLocalStatus> milestoneStatus =
      MilestoneLocalStatus.toDo.obs;

  // submissions (UI wrappers)
  final RxList<SubmissionUiModel> submissions = <SubmissionUiModel>[].obs;
  final RxList<BrandSubmissionUiModel> brandSubmissions =
      <BrandSubmissionUiModel>[].obs;

  // bottom checkboxes
  final RxBool confirmOwnership = false.obs;
  final RxBool acceptLicense = false.obs;
  final ApiClient _apiClient = Get.find<ApiClient>();

  final AccountTypeService _accountTypeService = Get.find<AccountTypeService>();
  @override
  void onInit() {
    super.onInit();

    if (arguments is Map) {
      final map = arguments as Map;
      milestone = map['milestone'] as Milestone;
      job = map['job'] as JobItem;
    } else {
      throw 'MilestoneDetails requires Milestone and JobItem in Get.arguments';
    }

    // build UI submissions from model if already exist
    if (milestone.submissions.isNotEmpty) {
      for (final submission in milestone.submissions) {
        final ui = SubmissionUiModel(index: submission.index);
        ui.serverId = submission.id;
        ui.descriptionController.text = submission.description;
        ui.amountController.text = submission.amount.toString();
        ui.linkController.text = submission.liveLink;
        ui.metricLabelController.text = submission.metricLabel;
        ui.metricValueController.text = submission.metricValue;
        ui.status.value = submission.status;
        ui.isSubmitted.value = true;
        ui.isExpanded.value = false;
        // proofs will be hydrated later if you store paths/urls
        submissions.add(ui);
      }
    } else {
      submissions.add(SubmissionUiModel(index: 1));
    }

    final isBrand = _accountTypeService.isBrand;
    final isPaidAd = job.campaignType == CampaignType.paidAd;

    if (isBrand) {
      if (isPaidAd) {
        brandSubmissions.assignAll([
          BrandSubmissionUiModel(
            index: 1,
            description: 'Description of the proof will be visible here',
            platformTitleKey: 'brand_submission_platform_1',
            platformLink: 'facebook.com/hania/live',
            avgPercent: 65.4,
            metrics: [
              BrandSubmissionMetric(
                labelKey: 'brand_metric_reach',
                leftValue: '200k',
                rightValue: '300k',
                progress: 200 / 300,
                targetKey: 'brand_submission_target_hit_75',
              ),
            ],
            expanded: true,
          ),
          BrandSubmissionUiModel(
            index: 2,
            description: 'Description of the proof will be visible here',
            platformTitleKey: 'brand_submission_platform_1',
            platformLink: 'facebook.com/hania/live',
            avgPercent: 65.4,
            metrics: [
              BrandSubmissionMetric(
                labelKey: 'brand_metric_reach',
                leftValue: '200k',
                rightValue: '300k',
                progress: 200 / 300,
                targetKey: 'brand_submission_target_hit_75',
              ),
            ],
            expanded: false,
          ),
          BrandSubmissionUiModel(
            index: 3,
            description: 'Description of the proof will be visible here',
            platformTitleKey: 'brand_submission_platform_1',
            platformLink: 'facebook.com/hania/live',
            avgPercent: 65.4,
            metrics: [
              BrandSubmissionMetric(
                labelKey: 'brand_metric_reach',
                leftValue: '200k',
                rightValue: '300k',
                progress: 200 / 300,
                targetKey: 'brand_submission_target_hit_75',
              ),
            ],
            expanded: false,
          ),
        ]);
      } else {
        brandSubmissions.assignAll([
          BrandSubmissionUiModel(
            index: 1,
            description: 'Description of the proof will be visible here',
            platformTitleKey: 'brand_submission_platform_1',
            platformLink: 'facebook.com/hania/live',
            avgPercent: 65.4,
            metrics: [
              BrandSubmissionMetric(
                labelKey: 'brand_metric_reach',
                leftValue: '200k',
                rightValue: '300k',
                progress: 200 / 300,
                targetKey: 'brand_submission_target_hit_75',
              ),
              BrandSubmissionMetric(
                labelKey: 'brand_metric_likes',
                leftValue: '50K',
                rightValue: '50K',
                progress: 1,
                targetKey: 'brand_submission_target_hit_75',
              ),
              BrandSubmissionMetric(
                labelKey: 'brand_metric_views',
                leftValue: '250K',
                rightValue: '250K',
                progress: 1,
                targetKey: 'brand_submission_target_hit_75',
              ),
              BrandSubmissionMetric(
                labelKey: 'brand_metric_comments',
                leftValue: '3K',
                rightValue: '3K',
                progress: 1,
                targetKey: 'brand_submission_target_hit_75',
              ),
            ],
            expanded: true,
          ),
        ]);
      }
    }

    _syncLocalStatusFromModel();
  }

  void toggleHeader() => headerExpanded.toggle();

  @override
  void onClose() {
    for (final s in submissions) {
      s.dispose();
    }
    super.onClose();
  }

  // --- Report Admin state ---
  final RxBool hasReportedToAdmin = false.obs;
  final Rxn<DateTime> reportAgainAt = Rxn<DateTime>();
  final RxList<AdminReportModel> submittedReports = <AdminReportModel>[].obs;

  // helper (no intl needed)
  String formatReportDateTime(DateTime dt) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    final day = dt.day.toString().padLeft(2, '0');
    final mon = months[dt.month - 1];
    final year = dt.year;

    int hour = dt.hour % 12;
    if (hour == 0) hour = 12;
    final minute = dt.minute.toString().padLeft(2, '0');
    final ampm = dt.hour >= 12 ? 'PM' : 'AM';

    return '$day $mon $year, $hour:$minute $ampm';
  }

  void submitAdminReport(String reason) {
    final r = reason.trim();
    if (r.isEmpty) {
      Get.snackbar('Required', 'Please write your reason.');
      return;
    }

    submittedReports.insert(
      0,
      AdminReportModel(reason: r, createdAt: DateTime.now()),
    );

    hasReportedToAdmin.value = true;
    // cooldown (you can change duration)
    reportAgainAt.value = DateTime.now().add(const Duration(days: 1));
  }

  // ---------- helpers ----------

  void _syncLocalStatusFromModel() {
    switch (milestone.status) {
      case MilestoneStatus.todo:
        milestoneStatus.value = MilestoneLocalStatus.toDo;
        break;
      case MilestoneStatus.inReview:
        milestoneStatus.value = MilestoneLocalStatus.inReview;
        break;
      case MilestoneStatus.paid:
        milestoneStatus.value = MilestoneLocalStatus.paid;
        break;
      case MilestoneStatus.approved:
        milestoneStatus.value = MilestoneLocalStatus.approved;
        break;
      case MilestoneStatus.partialPaid:
        milestoneStatus.value = MilestoneLocalStatus.partialPaid;
        break;
      case MilestoneStatus.declined:
        milestoneStatus.value = MilestoneLocalStatus.declined;
        break;
    }

    if (_accountTypeService.isInfluencer) {
      _loadInfluencerMilestoneDetails();
    }
  }

  int get declinedSubmissionCount => submissions
      .where((s) => s.status.value == SubmissionStatus.declined)
      .length;

  // status text for big pill
  String get statusChipText {
    switch (milestoneStatus.value) {
      case MilestoneLocalStatus.toDo:
        return 'To Do';
      case MilestoneLocalStatus.inReview:
        return 'In Review';
      case MilestoneLocalStatus.approved:
        return 'Approved';
      case MilestoneLocalStatus.paid:
        return 'Paid';
      case MilestoneLocalStatus.partialPaid:
        return 'Partial Paid';
      case MilestoneLocalStatus.declined:
        return '$declinedSubmissionCount Declined';
      case MilestoneLocalStatus.completed:
        return 'Completed'; // ✅
    }
  }

  Color get statusChipColor {
    switch (milestoneStatus.value) {
      case MilestoneLocalStatus.completed:
        return AppPalette.secondary;
      case MilestoneLocalStatus.paid:
      case MilestoneLocalStatus.approved:
      case MilestoneLocalStatus.partialPaid:
        return AppPalette.secondary;
      case MilestoneLocalStatus.inReview:
        return AppPalette.complemetaryFill;
      case MilestoneLocalStatus.declined:
        return AppPalette.requiredColor;
      case MilestoneLocalStatus.toDo:
        return AppPalette.neutralGrey;
    }
  }

  Color get statusTextColor {
    switch (milestoneStatus.value) {
      case MilestoneLocalStatus.completed:
        return AppPalette.secondary;
      case MilestoneLocalStatus.paid:
      case MilestoneLocalStatus.approved:
      case MilestoneLocalStatus.partialPaid:
        return AppPalette.secondary;
      case MilestoneLocalStatus.inReview:
        return AppPalette.complemetary;
      case MilestoneLocalStatus.declined:
        return AppPalette.requiredColor;
      case MilestoneLocalStatus.toDo:
        return AppPalette.neutralGrey;
    }
  }

  Color get statusChipTextColor {
    switch (milestoneStatus.value) {
      case MilestoneLocalStatus.inReview:
        return AppPalette.complemetary;
      default:
        return Colors.white;
    }
  }

  Color get statusBgColor {
    switch (milestoneStatus.value) {
      case MilestoneLocalStatus.completed:
        return AppPalette.thirdColor;
      case MilestoneLocalStatus.paid:
      case MilestoneLocalStatus.approved:
      case MilestoneLocalStatus.partialPaid:
        return AppPalette.thirdColor;
      case MilestoneLocalStatus.inReview:
        return AppPalette.gradient2;
      case MilestoneLocalStatus.declined:
        return AppPalette.errorGradient;
      case MilestoneLocalStatus.toDo:
        return AppPalette.gradient3;
    }
  }

  // payment progress: approved/requested amount vs milestone amount
  bool get showPaymentProgress => submissions.isNotEmpty;

  int _parseAmount(String raw) {
    // removes everything except digits
    final cleaned = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (cleaned.isEmpty) return 0;
    return int.tryParse(cleaned) ?? 0;
  }

  int get requestedAmount {
    int sum = 0;
    for (final s in submissions) {
      final v = _parseAmount(s.amountController.text);
      sum += v;
    }
    return sum;
  }

  int get approvedAmountFromModel => milestone.approvedAmount;

  int get milestoneAmountTotal => _parseAmount(milestone.amountLabel);

  double get paymentProgressValue {
    final total = milestoneAmountTotal;
    if (total == 0) return 0;
    // You can choose requestedAmount or approvedAmountFromModel based on flow
    return requestedAmount / total.clamp(1, total);
  }

  String get progressLeftLabel =>
      requestedAmount > 0 ? '৳$requestedAmount' : '৳0';

  String get progressRightLabel => milestone.amountLabel;

  // ---------- actions ----------

  void toggleOwnership() => confirmOwnership.toggle();
  void toggleLicense() => acceptLicense.toggle();

  void addSubmission() {
    submissions.add(SubmissionUiModel(index: submissions.length + 1));
  }

  Future<void> pickProofFor(int submissionIndex) async {
    final submission = submissions[submissionIndex];

    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg', 'png', 'mp4', 'mov', 'pdf'],
    );

    if (result != null && result.files.isNotEmpty) {
      submission.proofs.addAll(result.files);
    }
  }

  void removeProof(int submissionIndex, int proofIndex) {
    final submission = submissions[submissionIndex];
    if (proofIndex >= 0 && proofIndex < submission.proofs.length) {
      submission.proofs.removeAt(proofIndex);
    }
  }

  void enableEditForDeclined(SubmissionUiModel submission) {
    submission.isSubmitted.value = false;
  }

  /// Called from "Submit For Admin Review" button.
  void submitForReview() {
    if (!confirmOwnership.value || !acceptLicense.value) {
      Get.snackbar(
        'Action required',
        'Please confirm ownership and accept the terms.',
      );
      return;
    }

    final isInfluencer = _accountTypeService.isInfluencer;
    if (isInfluencer && milestone.id != null && milestone.id!.isNotEmpty) {
      _submitInfluencerMilestone(milestone.id!);
      return;
    }

    // Lock UI submissions and set status to In Review
    for (final ui in submissions) {
      ui.status.value = SubmissionStatus.inReview;
      ui.isSubmitted.value = true;
      ui.isExpanded.value = false;
    }

    // Build domain submissions and update milestone via copyWith
    final domainSubmissions = submissions.map((ui) {
      return Submission(
        index: ui.index,
        description: ui.descriptionController.text.trim(),
        amount: _parseAmount(ui.amountController.text),
        liveLink: ui.linkController.text.trim(),
        metricLabel: ui.metricLabelController.text.trim(),
        metricValue: ui.metricValueController.text.trim(),
        proofPaths: ui.proofs
            .map((f) => f.path ?? f.name) // you can adjust this later
            .toList(),
        status: ui.status.value,
      );
    }).toList();

    milestone = milestone.copyWith(
      status: MilestoneStatus.inReview,
      submissions: domainSubmissions,
    );
    milestoneStatus.value = MilestoneLocalStatus.inReview;

    Get.snackbar('Submitted', 'Milestone sent for admin review');
    // If you want to refresh parent:
    // Get.back(result: milestone);
  }

  Future<void> _loadInfluencerMilestoneDetails() async {
    final milestoneId = milestone.id;
    if (milestoneId == null || milestoneId.isEmpty) return;

    final result = await ApiErrorHandler.call(() async {
      final res = await _apiClient.dio.get(
        '/campaign/influencer/milestone/$milestoneId',
      );
      return res.data;
    }, showError: false);

    if (!result.isSuccess || result.data == null) return;

    final data = result.data as Map<String, dynamic>;
    final raw = data['data'] is Map<String, dynamic>
        ? data['data'] as Map<String, dynamic>
        : data;

    final milestoneJson = raw['milestone'] is Map<String, dynamic>
        ? raw['milestone'] as Map<String, dynamic>
        : raw;

    final statusRaw =
        raw['status']?.toString() ?? milestoneJson['status']?.toString();

    milestone = milestone.copyWith(
      id: milestoneJson['id']?.toString() ?? milestone.id,
      title:
          milestoneJson['contentTitle']?.toString().trim() ?? milestone.title,
      platform: milestoneJson['platform']?.toString() ?? milestone.platform,
      deliverable:
          milestoneJson['contentQuantity']?.toString() ?? milestone.deliverable,
      dayIndex: _intFrom(milestoneJson['deliveryDays']) ?? milestone.dayIndex,
      amountLabel: _amountLabelFrom(
        milestoneJson['amount'] ?? milestoneJson['paidAmount'],
      ),
      targets: PromotionTarget(
        reach: _intFrom(milestoneJson['expectedReach']),
        views: _intFrom(milestoneJson['expectedViews']),
        likes: _intFrom(milestoneJson['expectedLikes']),
        comments: _intFrom(milestoneJson['expectedComments']),
      ),
      status: _parseMilestoneStatus(statusRaw),
    );

    milestoneStatus.value = _localStatusFromMilestone(milestone.status);

    final submissionsRaw = (raw['submissions'] as List?) ?? const [];
    final mapped = submissionsRaw
        .whereType<Map>()
        .map((e) => _mapInfluencerSubmission(e.cast<String, dynamic>()))
        .toList();

    submissions.clear();
    if (mapped.isNotEmpty) {
      for (final s in mapped) {
        final ui = SubmissionUiModel(index: s.index);
        ui.serverId = s.id;
        ui.descriptionController.text = s.description;
        ui.amountController.text = s.amount.toString();
        ui.linkController.text = s.liveLink;
        ui.metricLabelController.text = s.metricLabel;
        ui.metricValueController.text = s.metricValue;
        ui.status.value = s.status;
        ui.isSubmitted.value = true;
        ui.isExpanded.value = false;
        submissions.add(ui);
      }
    } else {
      submissions.add(SubmissionUiModel(index: 1));
    }
  }

  Submission _mapInfluencerSubmission(Map<String, dynamic> json) {
    final metrics = json['metrics'] as Map<String, dynamic>?;
    final reach = _intFrom(metrics?['reach']);
    final views = _intFrom(metrics?['views']);
    final likes = _intFrom(metrics?['likes']);
    final comments = _intFrom(metrics?['comments']);

    final metric = _preferredMetricValue(
      reach: reach,
      views: views,
      likes: likes,
      comments: comments,
    );

    return Submission(
      id: json['id']?.toString(),
      index: (json['index'] as num?)?.toInt() ?? 1,
      description: json['description']?.toString() ?? '',
      amount: _intFrom(json['amount']) ?? 0,
      liveLink: _firstString(json['liveLinks']) ?? '',
      metricLabel: metric.label,
      metricValue: metric.value.toString(),
      proofPaths: _stringList(json['attachments']),
      status: _parseSubmissionStatus(json['status']?.toString()),
      achieved: PromotionTarget(
        reach: reach,
        views: views,
        likes: likes,
        comments: comments,
      ),
    );
  }

  Future<void> _submitInfluencerMilestone(String milestoneId) async {
    if (submissions.isEmpty) return;

    final ui = submissions.first;
    final link = ui.linkController.text.trim();
    final label = ui.metricLabelController.text.trim().toLowerCase();
    final value = _intFrom(ui.metricValueController.text) ?? 0;

    int views = 0;
    int reach = 0;
    int likes = 0;
    int comments = 0;

    if (label.contains('view')) {
      views = value;
    } else if (label.contains('like')) {
      likes = value;
    } else if (label.contains('comment')) {
      comments = value;
    } else {
      reach = value;
    }

    final payload = {
      'description': ui.descriptionController.text.trim(),
      'liveLinks': link.isEmpty ? [] : [link],
      'proofAttachments': ui.proofs
          .map((f) => f.path ?? f.name)
          .where((e) => e.trim().isNotEmpty)
          .toList(),
      'achievedViews': views,
      'achievedReach': reach,
      'achievedLikes': likes,
      'achievedComments': comments,
    };

    final Future<dynamic> Function() apiCall;
    if (ui.serverId != null && ui.status.value == SubmissionStatus.declined) {
      apiCall = () => _apiClient.dio.patch(
        '/campaign/influencer/submission/${ui.serverId}/resubmit',
        data: payload,
      );
    } else {
      apiCall = () => _apiClient.dio.post(
        '/campaign/influencer/milestone/$milestoneId/submit',
        data: payload,
      );
    }

    final result = await ApiErrorHandler.call(apiCall);
    if (!result.isSuccess) return;

    ui.status.value = SubmissionStatus.inReview;
    ui.isSubmitted.value = true;
    ui.isExpanded.value = false;
    milestone = milestone.copyWith(status: MilestoneStatus.inReview);
    milestoneStatus.value = MilestoneLocalStatus.inReview;

    Get.snackbar('Submitted', 'Milestone sent for admin review');
  }

  MilestoneStatus _parseMilestoneStatus(String? raw) {
    final v = (raw ?? '').toLowerCase();
    switch (v) {
      case 'in_review':
      case 'inreview':
        return MilestoneStatus.inReview;
      case 'paid':
        return MilestoneStatus.paid;
      case 'approved':
        return MilestoneStatus.approved;
      case 'partial_paid':
      case 'partialpaid':
        return MilestoneStatus.partialPaid;
      case 'declined':
        return MilestoneStatus.declined;
      case 'completed':
        return MilestoneStatus.approved;
      case 'to_do':
      case 'todo':
      default:
        return MilestoneStatus.todo;
    }
  }

  SubmissionStatus _parseSubmissionStatus(String? raw) {
    final v = (raw ?? '').toLowerCase();
    if (v.contains('declined')) return SubmissionStatus.declined;
    if (v.contains('approved')) return SubmissionStatus.approved;
    return SubmissionStatus.inReview;
  }

  MilestoneLocalStatus _localStatusFromMilestone(MilestoneStatus status) {
    switch (status) {
      case MilestoneStatus.inReview:
        return MilestoneLocalStatus.inReview;
      case MilestoneStatus.paid:
        return MilestoneLocalStatus.paid;
      case MilestoneStatus.approved:
        return MilestoneLocalStatus.approved;
      case MilestoneStatus.partialPaid:
        return MilestoneLocalStatus.partialPaid;
      case MilestoneStatus.declined:
        return MilestoneLocalStatus.declined;
      case MilestoneStatus.todo:
      default:
        return MilestoneLocalStatus.toDo;
    }
  }

  String _amountLabelFrom(dynamic value) {
    final v = _intFrom(value);
    if (v != null) return '৳$v';
    if (value is String && value.trim().isNotEmpty) return value;
    return '—';
  }

  int? _intFrom(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value);
    return null;
  }

  List<String> _stringList(dynamic value) {
    if (value is List) {
      return value
          .map((e) => e?.toString() ?? '')
          .where((e) => e.trim().isNotEmpty)
          .toList();
    }
    return const [];
  }

  String? _firstString(dynamic value) {
    if (value is List && value.isNotEmpty) {
      return value.first?.toString();
    }
    if (value is String && value.trim().isNotEmpty) return value;
    return null;
  }

  _MetricValue _preferredMetricValue({
    int? reach,
    int? views,
    int? likes,
    int? comments,
  }) {
    if (reach != null && reach > 0) return _MetricValue('Reach', reach);
    if (views != null && views > 0) return _MetricValue('Views', views);
    if (likes != null && likes > 0) return _MetricValue('Likes', likes);
    if (comments != null && comments > 0) {
      return _MetricValue('Comments', comments);
    }
    return const _MetricValue('Reach', 0);
  }

  BrandSubmissionUiModel? get selectedBrandSubmission {
    for (final s in brandSubmissions) {
      if (s.isExpanded.value) return s;
    }
    return brandSubmissions.isNotEmpty ? brandSubmissions.first : null;
  }

  void toggleBrandSubmissionExpanded(int index) {
    if (job.campaignType != CampaignType.paidAd) return;

    for (final s in brandSubmissions) {
      if (s.index == index) {
        // toggle selected; but collapse others always
        final next = !s.isExpanded.value;
        s.isExpanded.value = next;
      } else {
        s.isExpanded.value = false;
      }
    }
  }

  void approveSelectedBrandSubmission() {
    final isPaidAd = job.campaignType == CampaignType.paidAd;
    final target = selectedBrandSubmission;

    if (target == null) {
      Get.snackbar('No submission', 'Please expand a submission first.');
      return;
    }

    target.status.value = BrandSubmissionStatus.completed;
    target.declinedReason.value = null;

    // ✅ non-paidAd: only one submission -> overall milestone becomes Completed
    if (!isPaidAd) {
      milestoneStatus.value = MilestoneLocalStatus.completed;
      return;
    }

    // ✅ paidAd: mark expanded as completed; if all completed -> milestone completed
    final allDone = brandSubmissions.every(
      (s) => s.status.value == BrandSubmissionStatus.completed,
    );
    if (allDone) milestoneStatus.value = MilestoneLocalStatus.completed;
  }

  void declineSelectedBrandSubmission(String reason) {
    final target = selectedBrandSubmission;

    if (target == null) {
      Get.snackbar('No submission', 'Please expand a submission first.');
      return;
    }

    final r = reason.trim();
    if (r.isEmpty) {
      Get.snackbar('Required', 'Please write a reason.');
      return;
    }

    target.status.value = BrandSubmissionStatus.declined;
    target.declinedReason.value = r;
  }
}

class _MetricValue {
  final String label;
  final int value;

  const _MetricValue(this.label, this.value);

  _MetricValue copyWith({String? label, int? value}) {
    return _MetricValue(label ?? this.label, value ?? this.value);
  }
}
