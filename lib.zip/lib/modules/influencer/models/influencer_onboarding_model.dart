import '../../../core/models/social_link.dart';

class InfluencerOnboardingModel {
  String? fullAddress;
  String? thana;
  String? zilla;
  String? website;

  List<SocialLink> socialLinks = [];

  String? nidNumber;
  String? nidFrontImg;
  String? nidBackImg;

  Map<String, dynamic> toJson() {
    return {
      "fullAddress": fullAddress,
      "thana": thana,
      "zilla": zilla,
      "website": website,
      "socialLinks": socialLinks.map((e) => e.toJson()).toList(),
      "nidNumber": nidNumber,
      "nidFrontImg": nidFrontImg,
      "nidBackImg": nidBackImg,
    };
  }
}
